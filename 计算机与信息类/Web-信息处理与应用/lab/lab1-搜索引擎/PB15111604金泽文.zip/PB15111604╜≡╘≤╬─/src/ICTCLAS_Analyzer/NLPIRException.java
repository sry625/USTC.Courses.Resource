package ICTCLAS_Analyzer;

public class NLPIRException extends Exception{

    private static final long serialVersionUID = 6897134322647598254L;

    public NLPIRException(String erromsg) {
        super(erromsg);
    }
}